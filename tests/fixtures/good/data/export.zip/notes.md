# 数据分析会话

## 用户
分析 data/sales.csv。
